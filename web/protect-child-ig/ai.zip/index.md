# Home - PROTECT-CHILD Pediatric Transplant Data Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/ImplementationGuide/donor-ig/ImplementationGuide/pc.ig | *Version*:0.1.0 |
| Draft as of 2025-12-09 | *Computable Name*:PROTECTChildTransplantIG |

# PROTECT-CHILD Transplant Data Implementation Guide (DRAFT)

> **Status:**This Implementation Guide is a**draft**and may change based on ongoing work in PROTECT-CHILD.

This IG describes a FHIR-based representation of pediatric transplant data for the **PROTECT-CHILD** project.

At the centre is the **TransplantCase logical model**, which links:

* **Recipient & donor** 
* [`Patient`](StructureDefinition-patient-transplant.md)
* [`Donor`](StructureDefinition-donor.md)
 
* **Transplant & visits** 
* [`Transplant`](StructureDefinition-transplant.md) (index transplant encounter)
* [`Visit`](StructureDefinition-visit.md) (pre- and post-transplant follow-up)
 
* **Concomitant disease & immunosuppression** 
* [`ConcomitantDisease`](StructureDefinition-concomitant-disease.md), [`ConcomitantEpisode`](StructureDefinition-concomitant-episode.md), [`ConcomitantMedication`](StructureDefinition-concomitant-medication.md)
* [`PreMedication`](StructureDefinition-pre-medication.md), [`ImmunosuppressiveInductionPatient`](StructureDefinition-immunosuppressive-induction-patient.md), [`ImmunosuppressiveMaintenancePatient`](StructureDefinition-immunosuppressive-maintenance-patient.md), [`Immunosuppressant`](StructureDefinition-immunosuppressant.md)
 
* **Clinical data** 
* [`ClinicalVariable`](StructureDefinition-clinical-variable.md)
* [`LabResultObservation`](StructureDefinition-lab-result-observation.md), [`LabReport`](StructureDefinition-lab-report.md)
* [`Microbiology`](StructureDefinition-microbiology.md)
* [`PatientInstrumentalInvestigation`](StructureDefinition-patient-instrumental-investigation.md)
 
* **Biospecimens & omics** 
* [`BioSample`](StructureDefinition-biosample.md)
* [`GenomicTest`](StructureDefinition-genomic-test.md), [`EpigenomeStudy`](StructureDefinition-epigenome-study.md), [`MethylomicStudy`](StructureDefinition-methylomic-study.md)
* [`VariantOccurrence`](StructureDefinition-variant-occurrence.md), [`VariantAnnotation`](StructureDefinition-variant-annotation.md)
* [`ReferenceGenome`](StructureDefinition-reference-genome.md)
 
* **Events & outcomes** 
* [`PostEvent`](StructureDefinition-post-event.md)
* [`Outcome`](StructureDefinition-outcome.md)
 

